#include <rclcpp/rclcpp.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <turtlesim/msg/pose.hpp>
#include <cmath>

class TurtleMotion : public rclcpp::Node {
public:
    TurtleMotion() : Node("turtle_motion") {
        cmd_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel", 10);
        pose_sub_ = this->create_subscription<turtlesim::msg::Pose>(
            "/turtle1/pose", 10, std::bind(&TurtleMotion::poseCallback, this, std::placeholders::_1)
        );
        move_turtle();
    }

    void poseCallback(const turtlesim::msg::Pose::SharedPtr pose) {
        current_pose_ = *pose;
    }

    void move_turtle() {
        geometry_msgs::msg::Twist cmd;
        for (int i = 0; i < 5; ++i) {
            // Move forward for 2 units
            cmd.linear.x = 2.0; // Move forward at 2.0 units/sec
            cmd_pub_->publish(cmd);


            // Wait for 1 second after the forward motion
            rclcpp::sleep_for(std::chrono::seconds(1));

            // Turn right for 144 degrees (4*pi/5 radians)
            cmd.linear.x = 0.0;
            cmd.angular.z = -4.0 * M_PI / 5.0; // Turn 144 degrees in the clockwise direction
            cmd_pub_->publish(cmd);

            // Wait for the turtle to turn right
            rclcpp::sleep_for(std::chrono::seconds(1));
            cmd.angular.z = 0;
        }
    }

private:
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_pub_;
    rclcpp::Subscription<turtlesim::msg::Pose>::SharedPtr pose_sub_;
    turtlesim::msg::Pose current_pose_;
};

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<TurtleMotion>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
