import os
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import matplotlib.pyplot as plt
import random

# Load the saved model
loaded_model = load_model('hr_v_a.keras')

# Path to the directory containing the test images
test_images_dir = 'added_test/'
test_image_files = [filename for filename in os.listdir(test_images_dir) if os.path.isfile(os.path.join(test_images_dir, filename))]

# Choose a random image file from the list
image_filename = random.choice(test_image_files)
image_path = os.path.join(test_images_dir, image_filename)
new_image = load_img(image_path, target_size=(28, 28), color_mode='grayscale')
new_image_array = img_to_array(new_image) / 255.0
inverted_image_array = 1.0 - new_image_array  # Invert the pixel values
inverted_image_array = np.expand_dims(inverted_image_array, axis=0)
predicted_probs = loaded_model.predict(inverted_image_array)
predicted_class = np.argmax(predicted_probs)

# Extract the true label from the image filename
true_class = int(image_filename.split('_')[0])

# Plot the image and display the predicted and true labels
plt.figure(figsize=(8, 4))
plt.subplot(1, 2, 1)
plt.imshow(inverted_image_array.reshape(28, 28), cmap='gray')  
plt.title(f"True Label: {true_class}")
plt.subplot(1, 2, 2)
plt.bar(range(10), predicted_probs[0], tick_label=range(10))
plt.xlabel("Class")
plt.ylabel("Probability")
plt.title(f"Predicted Label: {predicted_class}")
plt.tight_layout()
plt.show()
