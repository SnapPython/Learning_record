import os
import numpy as np
from PIL import Image
import tensorflow as tf
from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Flatten, Dense,Dropout
import matplotlib.pyplot as plt
from PIL import ImageOps

# Find the path to the "added_test" folder in the current directory
data_dir = os.path.join(os.getcwd(), "added_test")

image_size = (28, 28)  

# Lists to store images and labels
images = []
labels = []

# Iterate through each file in the data directory
for filename in os.listdir(data_dir):
    if filename.endswith('.png'):  
        parts = filename.split('_')
        label = int(parts[0].split('.')[0])  # Extract label from the first part of the filename
        image_path = os.path.join(data_dir, filename)
        
        # Load, preprocess, and store the image
        image = Image.open(image_path).convert('L')  
        image = image.resize(image_size)
        image = 1.0 - (np.array(image) / 255.0)  
        images.append(image)
        labels.append(label)

custom_images = np.array(images)
custom_labels = np.array(labels)

# Visualize the first few images and their labels (for test)
#num_images_to_visualize = 5
#for i in range(num_images_to_visualize):
#    plt.imshow(custom_images[i], cmap='gray')
#    plt.title(f"Label: {custom_labels[i]}")
#    plt.show()


# Load MNIST dataset
mnist = tf.keras.datasets.mnist
(train_images, train_labels), (test_images, test_labels) = mnist.load_data()

combined_train_images = np.concatenate((train_images, custom_images), axis=0)
combined_train_labels = np.concatenate((train_labels, custom_labels), axis=0)


combined_train_indices = np.arange(combined_train_images.shape[0])
np.random.shuffle(combined_train_indices)

combined_train_images = combined_train_images[combined_train_indices]
combined_train_labels = combined_train_labels[combined_train_indices]

combined_train_images = combined_train_images / 255.0

# Save the combined dataset
np.savez('mnist_added.npz', images=combined_train_images, labels=combined_train_labels)

# Build the model
model = Sequential([
    Flatten(input_shape=(28, 28)),
    Dense(128, activation='relu'),
    Dropout(0.1),
    Dense(10, activation='softmax')
])

model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# Initialize lists to store training history
history = model.fit(combined_train_images, combined_train_labels, epochs=4, validation_data=(test_images, test_labels))

# Plot training history
plt.figure(figsize=(10, 4))


plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Model Accuracy')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend(['Train', 'Validation'], loc='upper left')


plt.subplot(1, 2, 2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model Loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['Train', 'Validation'], loc='upper left')
plt.tight_layout()
plt.show()

# Save the model
model.save('hr_v_a.keras')
